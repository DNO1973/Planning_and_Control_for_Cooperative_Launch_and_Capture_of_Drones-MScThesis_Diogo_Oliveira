function [t0, x0, u0, xs] = MEU_shift1(T, t0, x0, u, f_u, f_t, xs, ParamFixLine)
st_shuttle = x0;
con_shuttle = u(1,:)';
f_value = f_u(st_shuttle,con_shuttle);
st_shuttle = st_shuttle+ (T*f_value);
x0 = full(st_shuttle);



st_target = xs;

%straight line path generator
p_target = [xs(1); xs(2); xs(3)];
u_velocity_vector = straight_path_generator(p_target, ParamFixLine)

%straight line path following controller
[gammac,phic] = straight_path_following_controller(u_velocity_vector, xs(4), ParamFixLine)

%%achar as variaveis con_traget
con_target = [ParamFixLine.V; gammac; phic];
f_t_value = f_t(st_target,con_target);
st_target = st_target + (T*f_t_value);
xs = full(st_target);



t0 = t0 + T;
u0 = [u(2:size(u,1),:);u(size(u,1),:)];
end
