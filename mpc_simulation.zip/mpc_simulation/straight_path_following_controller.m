function [gammac,phic] = straight_path_following_controller(u, psi, ParamFixLine)

V = ParamFixLine.V;
gamma_limit = ParamFixLine.gamma_limit;
phi_limit = ParamFixLine.phi_limit;
kphi = ParamFixLine.kphi;

gammac = -sat(asin(u(3)/V), gamma_limit);

psid = atan2(u(2),u(1));

phic = sat(kphi*(psid- psi), phi_limit);
end


