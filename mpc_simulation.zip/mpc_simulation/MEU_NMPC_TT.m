% This code is for the implementation of the MPC for the target - 
% tracking (without gimbal and without obstacles scenario) problem using CasADi v3.5.5.
clear all; clc; close all;


addpath('D:\Docments\Matlab\toolbox\casadi-3.6.3-windows64-matlab2018b')
import casadi.*


set_param_fixed


%% Defining the system of Shuttle ------------------------------------------------------------------------------------------

T = 0.2;
N = 15;

% Constrains of UAV

  %input constrains
  %averiguar valores
v_shuttle_min = -8.5; v_shuttle_max = 8.5;
psi_shuttle_min = -inf; psi_shuttle_max = inf;
accel_shuttle_min = -4.5; accel_shuttle_max = 4.5; 
omegaz_shuttle_min = -inf; omegaz_shuttle_max = inf;

  %states constrains

  
% States of UAV with-out gimbal camera

x_shuttle = SX.sym('x_shuttle'); y_shuttle = SX.sym('y_shuttle'); z_shuttle = SX.sym('z_shuttle'); vx_shuttle = SX.sym('vx_shuttle'); vy_shuttle = SX.sym('vy_shuttle'); vz_shuttle = SX.sym('vz_shuttle'); psi_shuttle = SX.sym('psi_shuttle');   %states of the UAV
states_shuttle = [x_shuttle; y_shuttle; z_shuttle; psi_shuttle; vx_shuttle; vy_shuttle; vz_shuttle ];      n_states_shuttle = length(states_shuttle);               %UAV

% Controls of UAV that will be found by NMPC

accel_x_shuttle = SX.sym('accel_x_shuttle'); accel_y_shuttle = SX.sym('accel_y_shuttle'); accel_z_shuttle = SX.sym('accel_z_shuttle'); omegaz_shuttle = SX.sym('omegaz_shuttle');   % UAV cotrols parameters

controls_shuttle = [accel_x_shuttle; accel_y_shuttle; accel_z_shuttle;omegaz_shuttle]; n_controls_shuttle = length(controls_shuttle);
rhs_shuttle = [ vx_shuttle; vy_shuttle; vz_shuttle; omegaz_shuttle ; accel_x_shuttle; accel_y_shuttle; accel_z_shuttle];                                                                  %systems r.h.s

f_shuttle = Function('f_shuttle',{states_shuttle,controls_shuttle}, {rhs_shuttle});                                         % Nonlinear Mapping Function f(x,u)
U = SX.sym('U',n_controls_shuttle, N);                                                                % Desition Variables 
P = SX.sym('P',n_states_shuttle + 4);                                                        
% This consists of initial states of the UAV 1-5 and reference states 6-8(reference states are the target's states)

X = SX.sym('X',n_states_shuttle,(N+1));
% Consists of future predicted states of UAV

% Filling the defined sysem parameters of UAV --------------------------------------------------------------------------

X(:,1) = P(1:7) % initial state
for k = 1:N
    st = X(:,k); con = U(:,k);
    f_value = f_shuttle(st,con);
    st_next = st + T*f_value;
    X(:,k+1) = st_next;
end

ff = Function('ff',{U,P},{X});


%% Defining the system of Target ------------------------------------------------------------------------------------------

% Constrains of UAV

%input constrains
v_target_min = 10; v_target_max = 20;
psi_target_min = -inf; psi_target_max = inf;
  
%states constrains

gamma_target_min = -pi/6; gamma_target_max = pi/6;
phi_target_min = -pi/6; phi_target_max = pi/6;

% States of UAV 

x_target = SX.sym('x_target'); y_target = SX.sym('y_target'); z_target = SX.sym('z_target'); psi_target = SX.sym('psi_target');   %states of the UAV
states_target = [x_target; y_target; z_target; psi_target];      n_states_target = length(states_target);               %UAV

% Controls of UAV 

v_target = SX.sym('v_target'); gamma_target = SX.sym('gamma_target'); phi_target = SX.sym('phi_target');         % UAV cotrols parameters

controls_target = [v_target; gamma_target; phi_target]; n_controls_target = length(controls_target);
rhs_target = [v_target*cos(psi_target)*cos(gamma_target); v_target*sin(psi_target)*cos(gamma_target); -v_target*sin(gamma_target); (9.81/v_target)*tan(phi_target)];                                                        %systems r.h.s

%possivelmente nao vai ser usado e depois é na funcao shitf que se faz o controlo do target
f_target = Function('f_target',{states_target,controls_target}, {rhs_target});                                         % Nonlinear Mapping Function f(x,u)





%% Defining the system's constraints ------------------------------------------------------------------------------------------



obj = 0; %objective function
g = [];  %constrains of pitch angle theta


%weight matrices -- REVER PESOS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%FAZER ISTO BEM
Q = 1;
R = 1;


for k=1:N
    st = X(1:4,k); cont = U(:,k); % st - state, con - controls
    obj = obj + (st-P(8:11))'*Q*(st-P(8:11)) + con'*R*con; %objective function- diferenca entre os estados do shuttle com a posicao e psi do target, mais a deviation in control
end


%compute the constrains
 for k=1:N+1
     g = [g, X(4,k)]; %limit on shuttle yaw
     g = [g, X(5,k)]; %limit on shuttle velocity
     g = [g, X(6,k)]; %limit on shuttle velocity
     g = [g, X(7,k)]; %limit on shuttle velocity    
     
 end
 
% make the decision variables one column vector
OPT_variables = reshape(U,4*N,1);
nlp_prob = struct('f', obj, 'x', OPT_variables, 'g', g, 'p', P);

opts = struct;
opts.ipopt.max_iter = 100;
opts.ipopt.print_level =0;%0,3
opts.print_time = 0;
opts.ipopt.acceptable_tol =1e-8;
opts.ipopt.acceptable_obj_change_tol = 1e-6;

solver = nlpsol('solver', 'ipopt', nlp_prob,opts);

args = struct;

% inequality constraints (state constraints)

%possivelmente alguma coisa mal com aslimitacoes devido aos tamanhos das
%matrizes e ques
%%%%%adaptar caso se mude as cenas la de cima, por enquanto acho que funciona assim
args.lbg(1,1:4:4*(N+1)) = psi_shuttle_min;
args.ubg(1,1:4:4*(N+1)) = psi_shuttle_max;

args.lbg(1,2:4:4*(N+1)) = v_shuttle_min;
args.ubg(1,2:4:4*(N+1)) = v_shuttle_max;
args.lbg(1,3:4:4*(N+1)) = v_shuttle_min;
args.ubg(1,3:4:4*(N+1)) = v_shuttle_max;
args.lbg(1,4:4:4*(N+1)) = v_shuttle_min;
args.ubg(1,4:4:4*(N+1)) = v_shuttle_max;
%args.lbg(1,1:2:32) = 75;     args.lbg(1,2:2:32) = -0.2618;    % lower bound of height and theta 
%args.ubg(1,1:2:32) = 150;    args.ubg(1,2:2:32) =  0.2618;    % upper bound of height and theta 



% input constraints
%por enquanto acho que nao tem nada aqui, podia fazer sentido limitar a
%velociadde aqui mas como supostamento so se tem o controlo da aceleracao,
%acho que limita se a velocidade como estado

args.lbx(1,1:4:4*N) = accel_shuttle_min;
args.ubx(1,1:4:4*N) = accel_shuttle_max;
args.lbx(1,2:4:4*N) = accel_shuttle_min;
args.ubx(1,2:4:4*N) = accel_shuttle_max;
args.lbx(1,3:4:4*N) = accel_shuttle_min;
args.ubx(1,3:4:4*N) = accel_shuttle_max;
args.lbx(1,4:4:4*N) = omegaz_shuttle_min;
args.ubx(1,4:4:4*N) = omegaz_shuttle_max;
%args.lbx(1:3:3*N-1,1) = v_u_min; args.lbx(2:3:3*N,1) = omega_2_u_min; args.lbx(3:3:3*N,1) = omega_3_u_min;
%args.ubx(1:3:3*N-1,1) = v_u_max; args.ubx(2:3:3*N,1) = omega_2_u_max; args.ubx(3:3:3*N,1) = omega_3_u_max;




%% Simulation starts from here----------------------------------------------------------------------------------------------
t0 = 0;
x0 = [50;10;-30;0;0;0;0]; %initial location of shuttle
xs = [0;0;-20;0]; %reference for the shuttle which is the target's position and yaw
xx(:,1) = x0; %storing history of location the UAV
t(1) = t0;
u0 = zeros(N,4); %initial control of shuttle
sim_time = 20;

% NMPC starts form here

mpciter = 0;
xx1 = [];
u_cl = [];
xss = [];
ss = [];
ss(:,1) = xs;

main_loop = tic;
while (mpciter < sim_time/T)
    args.p = [x0;xs];
    args.x0 = reshape(u0',4*N,1); % initial value of the optimization variables
    %tic
    sol = solver('x0', args.x0, 'lbx', args.lbx, 'ubx', args.ubx,...
            'lbg', args.lbg, 'ubg', args.ubg,'p',args.p);    
    %toc
    u = reshape(full(sol.x)',4,N)';
    ff_value = ff(u',args.p); % compute OPTIMAL solution TRAJECTORY
    xx1(:,1:7,mpciter+1)= full(ff_value)'; %and storing it
    xss(:,1:4,mpciter+1) = full(xs)'; 
    
    u_cl= [u_cl ; u(1,:)];
    t(mpciter+1) = t0;
    [t0, x0, u0, xs] = MEU_shift1(T, t0, x0, u, f_shuttle, f_target, xs, ParamFixLine); % get the initialization of the next optimization step
                                                                          %apply control action to the system
    ss(:,mpciter+2) = xs;
    xx(:,mpciter+2) = x0;  
    mpciter
    t0
    mpciter = mpciter + 1;

end
main_loop_time = toc(main_loop)

%% Plotting stuff----------------------------------------------------------------------------------------------------------------------



plot3(ss(1,:),ss(2,:), ss(3,:),xx(1,:),xx(2,:), xx(3,:));
hold on;
title('Shuttle and Target Positions ("o" at 5 seconds interval)');
plot3(ss(1,1:25:end),ss(2,1:25:end), ss(3,1:25:end),'o','Color',"b");
plot3(xx(1,1:25:end),xx(2,1:25:end), xx(3,1:25:end),'o','Color',"r");
xlabel('X[m]'); ylabel('y[m]'); zlabel('z[m]');
legend('Target','Shuttle');
grid on;

hold off;
     figure(2);
     plot(1:sim_time/T + 1, xx(1:3,:), '-');
     hold on;
     title('Shuttle and Target Positions - 0.2seconds evolution');
     plot(1:sim_time/T + 1, ss(1:3,:), '--');
     legend('x_{shuttle}','y_{shuttle}','z_{shuttle}','x_{target}','y_{target}','z_{target}');  
    

 hold off;
 
 hold off;
     figure(3);
     plot(1:sim_time/T + 1, xx(4,:), '-');
     hold on;
     title('Shuttle and Target Yaw - 0.2seconds evolution');
     
     plot(1:sim_time/T + 1, ss(4,:), '--');
     legend('psi_{shuttle}','psi_{target}');  
    

 hold off;
 
 hold off;
     figure(4);
     plot(1:sim_time/T + 1, xx(4:6,:), '-');
     hold on;
     title('Shuttle Velocity - 0.2seconds evolution');
     legend('v_x','v_y','v_z');
    
    

 hold off;

%% Simulation --------------------------------------------------------------------------------------------------------------------------

% figh = figure
% for i=1:4*N+1
%     hold on;
%     plot3(ss(1,i),ss(2,i), ss(3,i),xx(1,i),xx(2,i), xx(3,i),'go', 'LineWidth', 4, 'MarkerSize', 1);
%     plot3(ss(1,i),ss(2,i), ss(3,i), 'bo', 'LineWidth', 4, 'MarkerSize', 1);
%     xlabel('X[m]'); ylabel('y[m]'); zlabel('z[m]');
%     legend('Target','Shuttle');
%     view([30+i 35]);
%     grid on;
%     hold off;
%     drawnow;
%     
%     movieVector(i) = getframe(figh, [10 10 520 400]);
%     
% end
% 
% myWriter = VideoWriter('Tracking4');
% myWriter.FrameRate = 20;
% 
% open(myWriter);
% writeVideo(myWriter, movieVector);
% close(myWriter);
